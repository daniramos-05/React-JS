import React from 'react'

const Cart = () => {
  return (
    <div> 
        <h2>Carrito </h2>
    </div>
  )
}
