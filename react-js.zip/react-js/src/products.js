export const productos = [
  {
    id: 1,
    nombre: "Remera",
    img: "https://res.cloudinary.com/dwfbrcxgu/image/upload/v1755737206/remera_aw0dxv.jpg",
    description: 
    "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dolore modi cupiditate cumque dolorem, totam impedit excepturi ad corporis ex omnis molestiae quas ut nostrum dicta, quo saepe tenetur numquam voluptatum?",
    precio: "$10.000",
    categoria: "remera",
    stock: 10,
  },
  {
    id: 2,
    nombre: "Remera",
    img: "https://res.cloudinary.com/dwfbrcxgu/image/upload/v1757698105/remera2_n912vl.png",
    description: 
    "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dolore modi cupiditate cumque dolorem, totam impedit excepturi ad corporis ex omnis molestiae quas ut nostrum dicta, quo saepe tenetur numquam voluptatum?",
    precio: "$10.000",
    categoria: "remera",
    stock: 10,
  },
  {
    id: 3,
    nombre: "Remera",
    img: "https://res.cloudinary.com/dwfbrcxgu/image/upload/v1757698105/remera1_wc6a0r.jpg",
    description: 
    "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dolore modi cupiditate cumque dolorem, totam impedit excepturi ad corporis ex omnis molestiae quas ut nostrum dicta, quo saepe tenetur numquam voluptatum?",
    precio: "$10.000",
    categoria: "remera",
    stock: 10,
  },
  {
    id: 4,
    nombre: "Pantalon",
    img: "https://res.cloudinary.com/dwfbrcxgu/image/upload/v1755782067/pantalon_raw_denim_c22kd4.jpg",
    description: "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dolore modi cupiditate cumque dolorem, totam impedit excepturi ad corporis ex omnis molestiae quas ut nostrum dicta, quo saepe tenetur numquam voluptatum?",
    precio: "$42.000",
    categoria: "pantalon",
  },
  {
    id: 5,
    nombre: "Pantalon",
    img: "https://res.cloudinary.com/dwfbrcxgu/image/upload/v1755781827/pantalon_carhartt2_jtuz0s.webp",
    description: 
    "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dolore modi cupiditate cumque dolorem, totam impedit excepturi ad corporis ex omnis molestiae quas ut nostrum dicta, quo saepe tenetur numquam voluptatum?",
    precio: "$45.000",
    categoria: "pantalon",
    stock: 10,
  },
  {
    id: 6,
    nombre: "Pantalon",
    img: "https://res.cloudinary.com/dwfbrcxgu/image/upload/v1755737207/pantalon_rzw6fa.jpg",
    description: 
    "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dolore modi cupiditate cumque dolorem, totam impedit excepturi ad corporis ex omnis molestiae quas ut nostrum dicta, quo saepe tenetur numquam voluptatum?",
    precio: "$40.000",
    categoria: "pantalon",
    stock: 10,
  },
  {
    id: 7,
    nombre: "Pantalon",
    img: "https://res.cloudinary.com/dwfbrcxgu/image/upload/v1755781833/pantalon_carhartt3_sbxth0.webp",
    description: 
    "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dolore modi cupiditate cumque dolorem, totam impedit excepturi ad corporis ex omnis molestiae quas ut nostrum dicta, quo saepe tenetur numquam voluptatum?",
    precio: "$45.000",
    categoria: "pantalon",
    stock: 10,
  },
  {
    id: 8,
    nombre: "Pantalon",
    img: "https://res.cloudinary.com/dwfbrcxgu/image/upload/v1755781826/pantalon_carhartt_l6qtdo.webp",
    description: 
    "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dolore modi cupiditate cumque dolorem, totam impedit excepturi ad corporis ex omnis molestiae quas ut nostrum dicta, quo saepe tenetur numquam voluptatum?",
    precio: "$45.000",
    categoria: "pantalon",
    stock: 10,
  },
  {
    id: 9,
    nombre: "Zapatillas",
    img: "https://res.cloudinary.com/dwfbrcxgu/image/upload/v1755737207/zapatillas_wrnjuu.webp",
    description: 
    "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dolore modi cupiditate cumque dolorem, totam impedit excepturi ad corporis ex omnis molestiae quas ut nostrum dicta, quo saepe tenetur numquam voluptatum?",
    precio: "$110.000",
    categoria: "calzado",
    stock: 10,
  },
  {
    id: 10,
    nombre: "Zapatillas",
    img: "https://res.cloudinary.com/dwfbrcxgu/image/upload/v1757718543/zapatillas1_tiglz2.avif",
    description: 
    "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dolore modi cupiditate cumque dolorem, totam impedit excepturi ad corporis ex omnis molestiae quas ut nostrum dicta, quo saepe tenetur numquam voluptatum?",
    precio: "$150.000",
    categoria: "calzado",
    stock: 10,
  },
  {
    id: 11,
    nombre: "Zapatillas",
    img: "https://res.cloudinary.com/dwfbrcxgu/image/upload/v1757718994/zapatillas2_uoc3i4.webp",
    description: 
    "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dolore modi cupiditate cumque dolorem, totam impedit excepturi ad corporis ex omnis molestiae quas ut nostrum dicta, quo saepe tenetur numquam voluptatum?",
    precio: "$160.000",
    categoria: "calzado",
    stock: 10,
  },
  {
    id: 12,
    nombre: "Mocasines",
    img: "https://res.cloudinary.com/dwfbrcxgu/image/upload/v1757718709/mocasines_t4jjin.webp",
    description: 
    "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dolore modi cupiditate cumque dolorem, totam impedit excepturi ad corporis ex omnis molestiae quas ut nostrum dicta, quo saepe tenetur numquam voluptatum?",
    precio: "$110.000",
    categoria: "calzado",
    stock: 10,
  },
  {
    id: 13,
    nombre: "Borcegos",
    img: "https://res.cloudinary.com/dwfbrcxgu/image/upload/v1755781827/timberland_pgunws.avif",
    description: 
    "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dolore modi cupiditate cumque dolorem, totam impedit excepturi ad corporis ex omnis molestiae quas ut nostrum dicta, quo saepe tenetur numquam voluptatum?",
    precio: "$200.000",
    categoria: "calzado",
    stock: 10,
  },
  {
    id: 14,
    nombre: "Campera",
    img: "https://res.cloudinary.com/dwfbrcxgu/image/upload/v1755781184/campera_zmgbth.jpg",
    description: 
    "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dolore modi cupiditate cumque dolorem, totam impedit excepturi ad corporis ex omnis molestiae quas ut nostrum dicta, quo saepe tenetur numquam voluptatum?",
    precio: "$180.000",
    categoria: "campera",
    stock: 10,
  },
  {
    id: 15,
    nombre: "Campera",
    img: "https://res.cloudinary.com/dwfbrcxgu/image/upload/v1755781826/campera_raw_denim_h8r2rd.webp",
    description: 
    "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dolore modi cupiditate cumque dolorem, totam impedit excepturi ad corporis ex omnis molestiae quas ut nostrum dicta, quo saepe tenetur numquam voluptatum?",
    precio: "$100.000",
    categoria: "campera",
    stock: 10,
  },
  {
    id: 16,
    nombre: "Campera",
    img: "https://res.cloudinary.com/dwfbrcxgu/image/upload/v1757698631/campera5_iacygz.png",
    description: 
    "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dolore modi cupiditate cumque dolorem, totam impedit excepturi ad corporis ex omnis molestiae quas ut nostrum dicta, quo saepe tenetur numquam voluptatum?",
    precio: "$120.000",
    categoria: "campera",
    stock: 10,
  },
  {
    id: 17,
    nombre: "Campera",
    img: "https://res.cloudinary.com/dwfbrcxgu/image/upload/v1757698630/campera6_dgpyrc.webp",
    description: 
    "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dolore modi cupiditate cumque dolorem, totam impedit excepturi ad corporis ex omnis molestiae quas ut nostrum dicta, quo saepe tenetur numquam voluptatum?",
    precio: "$120.000",
    categoria: "campera",
    stock: 10,
  },
  {
    id: 18,
    nombre: "Campera",
    img: "https://res.cloudinary.com/dwfbrcxgu/image/upload/v1757698413/campera3_wbwlyi.jpg",
    description: 
    "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dolore modi cupiditate cumque dolorem, totam impedit excepturi ad corporis ex omnis molestiae quas ut nostrum dicta, quo saepe tenetur numquam voluptatum?",
    precio: "$140.000",
    categoria: "campera",
    stock: 10,
  },
  {
    id: 19,
    nombre: "Campera",
    img: "https://res.cloudinary.com/dwfbrcxgu/image/upload/v1757698412/campera2_i49vow.avif",
    description: 
    "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dolore modi cupiditate cumque dolorem, totam impedit excepturi ad corporis ex omnis molestiae quas ut nostrum dicta, quo saepe tenetur numquam voluptatum?",
    precio: "$140.000",
    categoria: "campera",
    stock: 10,
  },
  {
    id: 20,
    nombre: "Campera",
    img: "https://res.cloudinary.com/dwfbrcxgu/image/upload/v1757698413/campera4_tsakl4.jpg",
    description: 
    "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dolore modi cupiditate cumque dolorem, totam impedit excepturi ad corporis ex omnis molestiae quas ut nostrum dicta, quo saepe tenetur numquam voluptatum?",
    precio: "$140.000",
    categoria: "campera",
    stock: 10,
  },
  {
    id: 21,
    nombre: "Anteojos",
    img: "https://res.cloudinary.com/dwfbrcxgu/image/upload/v1755737206/anteojos_euupci.jpg",
    description: 
    "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dolore modi cupiditate cumque dolorem, totam impedit excepturi ad corporis ex omnis molestiae quas ut nostrum dicta, quo saepe tenetur numquam voluptatum?",
    precio: "$10.000",
    categoria: "accesorios",
    stock: 10,
  },
  {
    id: 22,
    nombre: "Anteojos",
    img: "https://res.cloudinary.com/dwfbrcxgu/image/upload/v1757717756/anteojos2_zfeovn.jpg",
    description: 
    "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dolore modi cupiditate cumque dolorem, totam impedit excepturi ad corporis ex omnis molestiae quas ut nostrum dicta, quo saepe tenetur numquam voluptatum?",
    precio: "$10.000",
    categoria: "accesorios",
    stock: 10,
  },
  {
    id: 23,
    nombre: "Anteojos",
    img: "https://res.cloudinary.com/dwfbrcxgu/image/upload/v1757717608/anteojos3_orvrhl.jpg",
    description: 
    "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dolore modi cupiditate cumque dolorem, totam impedit excepturi ad corporis ex omnis molestiae quas ut nostrum dicta, quo saepe tenetur numquam voluptatum?",
    precio: "$10.000",
    categoria: "accesorios",
    stock: 10,
  },
  {
    id: 24,
    nombre: "Reloj",
    img: "https://res.cloudinary.com/dwfbrcxgu/image/upload/v1755737646/reloj_s41eap.avif",
    description: 
    "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dolore modi cupiditate cumque dolorem, totam impedit excepturi ad corporis ex omnis molestiae quas ut nostrum dicta, quo saepe tenetur numquam voluptatum?",
    precio: "$50.000",
    categoria: "accesorios",
    stock: 10,
  },
  {
    id: 25,
    nombre: "Reloj",
    img: "https://res.cloudinary.com/dwfbrcxgu/image/upload/v1757717608/reloj2_gk0bam.png",
    description: 
    "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dolore modi cupiditate cumque dolorem, totam impedit excepturi ad corporis ex omnis molestiae quas ut nostrum dicta, quo saepe tenetur numquam voluptatum?",
    precio: "$50.000",
    categoria: "accesorios",
    stock: 10,
  },
  {
    id: 26,
    nombre: "Reloj",
    img: "https://res.cloudinary.com/dwfbrcxgu/image/upload/v1757717608/reloj1_onbead.jpg",
    description: 
    "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dolore modi cupiditate cumque dolorem, totam impedit excepturi ad corporis ex omnis molestiae quas ut nostrum dicta, quo saepe tenetur numquam voluptatum?",
    precio: "$50.000",
    categoria: "accesorios",
    stock: 10,
  },
  {
    id: 27,
    nombre: "Bermuda",
    img: "https://res.cloudinary.com/dwfbrcxgu/image/upload/v1757718061/bermuda_nsvufg.webp",
    description: 
    "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dolore modi cupiditate cumque dolorem, totam impedit excepturi ad corporis ex omnis molestiae quas ut nostrum dicta, quo saepe tenetur numquam voluptatum?",
    precio: "$35.000",
    categoria: "bermuda",
    stock: 10,
  },
  {
    id: 28,
    nombre: "Bermuda",
    img: "https://res.cloudinary.com/dwfbrcxgu/image/upload/v1757718062/bermuda2_y8io1z.png",
    description: 
    "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dolore modi cupiditate cumque dolorem, totam impedit excepturi ad corporis ex omnis molestiae quas ut nostrum dicta, quo saepe tenetur numquam voluptatum?",
    precio: "$35.000",
    categoria: "bermuda",
    stock: 10,
  },
  {
    id: 29,
    nombre: "Bermuda",
    img: "https://res.cloudinary.com/dwfbrcxgu/image/upload/v1757718061/bermuda1_eyllmw.webp",
    description: 
    "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dolore modi cupiditate cumque dolorem, totam impedit excepturi ad corporis ex omnis molestiae quas ut nostrum dicta, quo saepe tenetur numquam voluptatum?",
    precio: "$35.000",
    categoria: "bermuda",
  },
];

export const getProductos = () => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      resolve(productos);
    }, 1000);
  })
} 